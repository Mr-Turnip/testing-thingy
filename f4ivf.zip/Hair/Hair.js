/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Hair extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Hair", "./Hair/costumes/Hair.png", { x: 44, y: 24 })
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.size = 400;
    this.moveBehind();
    while (true) {
      this.goto(
        Math.round(this.stage.vars.x / 48) * -4 + 0,
        Math.round(this.stage.vars.y / 108) * -4 + 80
      );
      yield;
    }
  }
}
