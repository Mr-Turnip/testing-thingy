/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Eyes extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Eyes", "./Eyes/costumes/Eyes.png", { x: 23, y: 14 })
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.size = 400;
    this.moveAhead();
    while (true) {
      this.goto(
        Math.round(this.stage.vars.x / 24) * 4 + 0,
        Math.round(this.stage.vars.y / 18) * 4 + 0
      );
      yield;
    }
  }
}
