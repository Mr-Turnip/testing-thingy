/* eslint-disable require-yield, eqeqeq */
<script src="webgazer.js" type="text/javascript">

var prediction = webgazer.getCurrentPrediction();
if (prediction) {
    var x = prediction.x;
    var y = prediction.y;
}

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.png", {
        x: 480,
        y: 360
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];

    this.vars.myVariable = 0;
    this.vars.x = -12;
    this.vars.y = 20;

    this.watchers.x = new Watcher({
      label: "x",
      style: "large",
      visible: true,
      value: () => this.vars.x,
      x: 245,
      y: 175
    });
    this.watchers.y = new Watcher({
      label: "y",
      style: "large",
      visible: true,
      value: () => this.vars.y,
      x: 245,
      y: 148
    });
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.vars.x = x;
      this.vars.y = y;
      yield;
    }
  }
}
