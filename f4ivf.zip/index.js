import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Body from "./Body/Body.js";
import Eyes from "./Eyes/Eyes.js";
import Hair from "./Hair/Hair.js";
import Head from "./Head/Head.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Body: new Body({
    x: -4,
    y: -48,
    direction: 90,
    costumeNumber: 1,
    size: 400,
    visible: true,
    layerOrder: 2
  }),
  Eyes: new Eyes({
    x: -36,
    y: 40,
    direction: 90,
    costumeNumber: 1,
    size: 400,
    visible: true,
    layerOrder: 4
  }),
  Hair: new Hair({
    x: 20,
    y: 72,
    direction: 90,
    costumeNumber: 1,
    size: 400,
    visible: true,
    layerOrder: 1
  }),
  Head: new Head({
    x: -8,
    y: -40,
    direction: 90,
    costumeNumber: 1,
    size: 400,
    visible: true,
    layerOrder: 3
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;
